
window.addEventListener('DOMContentLoaded', (event) => {

  function update_todo() {
  let x = document.querySelectorAll(".todo_names");
  x.forEach(  (todo_name)=> {
    todo_name.addEventListener("input", function() {
    if (todo_name.innerText.length > 0) {
       // awesome filter to Force no enter can used in code edito
    todo_name.innerHTML = todo_name.innerHTML.trim()


    }
     // send ajax update request
      console.log("input event fired");
      var xhttp = new XMLHttpRequest();
      description = todo_name.innerText.trim();
      todo_id = todo_name.getAttribute('data-todo-id');
      xhttp.open("GET", "/todos/edit?description=" + description + "&todoid=" + todo_id);
      xhttp.send();

      xhttp.onreadystatechange = function() {
          if (this.readyState === 4 && this.status === 200) {
            // on successful response
            console.log(xhttp.responseText);

            setTimeout(function(){ todo_name.innerHTML = xhttp.responseText; }, 5000);

          }
      };


    }, false);
  })
  };
  update_todo();
})
