
window.addEventListener('DOMContentLoaded', (event) => {

  function update_todo() {
  let x = document.querySelectorAll(".todo_names");
  x.forEach(  (todo_name)=> {
    todo_name.addEventListener("input", function() {
    if (todo_name.innerText.length > 0) {
       // awesome filter to Force no enter can used in code edito
    todo_name.innerHTML = todo_name.innerHTML.trim()


    }
     // send ajax update request
      console.log("input event fired");
      var xhttp = new XMLHttpRequest();
      description = todo_name.innerText.trim();
      todo_id = todo_name.getAttribute('data-todo-id');
      xhttp.open("GET", "/todos/edit?description=" + description + "&todoid=" + todo_id);
      xhttp.send();

      xhttp.onreadystatechange = function() {
          if (this.readyState === 4 && this.status === 200) {
            // on successful response
            console.log(xhttp.responseText);

            setTimeout(function(){ todo_name.innerHTML = xhttp.responseText; }, 5000);

          }
      };


    }, false);
  })
  };
  update_todo();

  let newtodo = document.getElementById('ntodo');
  let todoname = document.getElementById('name_value');


  newtodo.onsubmit = function(e) {
    e.preventDefault();
    fetch('/todos/ajax_add', {
      method: 'POST',
      body: JSON.stringify({
        'name': document.getElementById('name_value').value,
        'id': document.getElementById('lid_input').value
      }),
      headers: {
        'Content-Type': 'application/json'
      }
    }).then(function(response) {
         return response.json();
     }).then(function(jsonres){
        console.log(jsonres['name']);
        let answer_html = `<a class="list-group-item delete_todo1" style="display:block;"><span class="update_box">
              <input type="checkbox" name="update_${jsonres['id']}"></span> <span data-todo-id="${jsonres['id']}" class="todo_names" contenteditable="true">${jsonres['name']}</span> (${jsonres['id']})
              <i id="${jsonres['id']}" class="close_btn fa fa-close delete_todo" data-todo-id="${jsonres['id']}"></i>
            </a>`;
            let father = document.getElementById('todos_father');
            father.innerHTML += answer_html;
            document.getElementById('name_value').value = '';
            document.getElementById('lid_input').value = '';

     });
  }



})
